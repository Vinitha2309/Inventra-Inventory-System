package com.inventra.inventra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventraApplicationTests {

	@Test
	void contextLoads() {
	}

}
