package com.inventra.inventra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventraApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventraApplication.class, args);
	}

}
